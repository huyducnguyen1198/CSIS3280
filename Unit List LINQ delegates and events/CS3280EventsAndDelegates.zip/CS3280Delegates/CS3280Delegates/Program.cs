﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS3280Delegates
{
    class Program
    {
        // delegate defines a type safe function pointer
        // here operation is the name of the function pointer or delegate
        // it can point to a method
        // and it is typesafe, it can only point to any method
        // that has same type as delegate
        // means, it takes 2 int as arguments or parameters and an int as return. 
        delegate int operation(int a, int b);
        static event operation operationFired;
        static void Main(string[] args)
        {
            MathOperations m = new MathOperations();
            // create delegate and make it point to a method. 
            // m.Add is the handler method
            operation op = new operation(m.Add);
            // associate event with delegate;
            operationFired += new operation(m.Add);
            // fire the event, or execute the event. 
            int answer = operationFired.Invoke(3, 4);
            // print the result;
            System.Console.WriteLine(answer);
            
            
            
            System.Console.ReadLine();


        }
    }
}
