﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS3280Delegates
{
    class Program
    {
        // delegate defines a type safe function pointer
        // here operation is the name of the function pointer or delegate
        // it can point to a method
        // and it is typesafe, it can only point to any method
        // that has same type as delegate
        // means, it takes 2 int as arguments or parameters and an int as return. 
        delegate int operation(int a, int b);
        static void Main(string[] args)
        {
            MathOperations m = new MathOperations();
            operation op = m.Add;
            int a = 3;
            
            System.Console.WriteLine(op(3, 4));

            
            op = m.Subtract;
            System.Console.WriteLine(op(3, 4));

            // we are violating type safety
            //op = m.Square;

            Demo demo = new Demo();
            Demo.operation op1 = new Demo.operation(m.Add);
            int ans = demo.DemoMethod(op1, 3, 4);
            System.Console.WriteLine(ans);

            
            System.Console.ReadLine();


        }
    }
}
