﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserDefinedInterface
{
    class Program
    {
        static readonly decimal HIGHER_EARNING = 750;
        static readonly decimal INFLATION_RATE = 0.02m;
        static void Main(string[] args)
        {
            SalariedEmployee salariedEmploye = new SalariedEmployee("John", "Smith", "111-111-1111", 800m);
            HourlyEmployee hourlyEmployee = new HourlyEmployee("Karen", "Price", "222-222-2222", 22.5m, 40);
            CommisionEmployee commisionEmployee = new CommisionEmployee("Sue", "Jones", "333-333-333", 1000m, 0.10m);
            BasePlusCommisionEmployee basePlusCommisionEmployee = new BasePlusCommisionEmployee("Bob", "Lewis", "444-444-4444", 1000m, 0.08m, 300);
            BasePlusCommisionEmployee basePlusCommisionEmployee2 = new BasePlusCommisionEmployee("Alex", "Lewis", "555-444-4444", 1000m, 0.08m, 350);
            //Invoice invoice = new Invoice("Part1", "Part 1 Desc", 10, 4.99m);
            List<Employee> employeeList = new List<Employee>();
            employeeList.Add(salariedEmploye);
            employeeList.Add(hourlyEmployee);
            employeeList.Add(commisionEmployee);
            employeeList.Add(basePlusCommisionEmployee);
            employeeList.Add(basePlusCommisionEmployee2);
            

            //foreach (Employee item in employeeList) {
            //    System.Console.WriteLine(item);
            //}

            // ******************** starting linq

            System.Console.WriteLine("******************** starting linq");

            // fina all employees whose salary is greather than 750; high earning.
            var a = "abcd";
            var higherEarnerList = employeeList.Where(x => x.Earning() >= HIGHER_EARNING).ToList();
            //foreach (Employee item in higherEarnerList)
            //{
            //    System.Console.WriteLine(item);
            //}


            // fina all the employees whose last name is Lewis.

            var lewisLastNameList = employeeList.Where(x => x.LastName == "Lewis").ToList();
            System.Console.WriteLine("******************** starting printing employee with last name lewis");
            foreach (Employee item in lewisLastNameList)
            {
                System.Console.WriteLine(item);
            }



            var lastNameListWithS = employeeList.Where(x => x.LastName.StartsWith("S")).ToList();
            System.Console.WriteLine("******************** starting printing employees where Last name starts with S");
            foreach (Employee item in lastNameListWithS)
            {
                System.Console.WriteLine(item);
            }


            System.Console.WriteLine("******************** Projection Operation");
            System.Console.WriteLine("******************** Find Social Security number of all the high earners");

            var ssnOfHigherEarnerList = employeeList.Where(x => x.Earning() > HIGHER_EARNING).Select(z => z.SSN).ToList();
            foreach (String item in ssnOfHigherEarnerList )
            {
                System.Console.WriteLine(item);
            }

            System.Console.WriteLine("******************** Find Social Security number of all the employees");
            var ssnOfAllEmployees = employeeList.Select(y => y.SSN);
            foreach (String item in ssnOfAllEmployees)
            {
                System.Console.WriteLine(item);
            }

            System.Console.WriteLine("******************** Find first name and last name  and earing of all the high earners");

            var firstLastOfHigherEarners = employeeList.Where(x => x.Earning() >= HIGHER_EARNING).Select(y => y.FirstName + " " + y.LastName + " " + y.Earning()).ToList();
            foreach(String item in firstLastOfHigherEarners)
            {
                System.Console.WriteLine(item);
            }


            System.Console.WriteLine("******************** Ordering Operation");
            // sort the employee by first name asc

            System.Console.WriteLine("******************** sort the employee by first name asc");
            var employeeSortedByFirstName = employeeList.OrderBy(x => x.FirstName).ToList();
            foreach (Employee item in employeeSortedByFirstName)
            {
                System.Console.WriteLine(item);
            }

            // sort the employee by earning. 

            System.Console.WriteLine("******************** sort the employee by earning. ");
            var employeeSortedByEarning = employeeList.OrderBy(x => x.Earning()).ToList();

            // sort the higher earners by last name.

            System.Console.WriteLine("******************** sort the higher earners by last name.");
            var higherEarnerByLastNameList = employeeList.Where(x => x.Earning() > HIGHER_EARNING).OrderBy(y => y.LastName);






            System.Console.WriteLine("******************** aggregation Operation");

            System.Console.WriteLine("******************** Find total cost associated with all the employees");
            var totalCost = employeeList.Sum(x => x.Earning());


            System.Console.WriteLine("******************** Find average cost associated with higer earners");

            var higherEarnersAvgCost = employeeList.Where(x => x.Earning() >= HIGHER_EARNING).Average(y => y.Earning());

            
            System.Console.ReadLine();


        }
    }
}
