﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SampleCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.btnAns2.Click += new EventHandler(btnAdd_Click);

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // btnAdd child class object
            // sender is my base class object, base class is object itself. 
            //Button b = (Button)sender;
            //MessageBox.Show(b.Text);
            int num1 = int.Parse(txtNum1.Text);
            int num2 = int.Parse(txtNum2.Text);
            int ans = num1 + num2;

            lblAns.Text = ans.ToString();

            //checkBox1.Invoke(new EventHandler(checkBox1_CheckedChanged));
            checkBox1.Invoke(new EventHandler(checkBox1_CheckedChanged), checkBox1, null);

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("I am inside checkbox check/uncheck.");
            if (sender is CheckBox) {
                CheckBox ch = (CheckBox)sender;
                MessageBox.Show(ch.Checked.ToString());
            }
           

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("I am inside radio button click.");
        }
    }
}
