﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserDefinedInterface
{
    class Program
    {
        static void Main(string[] args)
        {
            SalariedEmployee salariedEmploye = new SalariedEmployee("John", "Smith", "111-111-1111", 800m);
            HourlyEmployee hourlyEmployee = new HourlyEmployee("Karen", "Price", "222-222-222", 22.5m, 40);
            CommisionEmployee commisionEmployee = new CommisionEmployee("Sue", "Jones", "333-333-333", 1000m, 0.10m);
            BasePlusCommisionEmployee basePlusCommisionEmployee = new BasePlusCommisionEmployee("Bob", "Lewis", "444-444-4444", 1000m, 0.08m, 300);
            Invoice invoice = new Invoice("Part1", "Part 1 Desc", 10, 4.99m);

            // Without using polymorphism, let's print all the payments. 
            //System.Console.WriteLine("Salaried Employee Payment: " + salariedEmploye.GetPaymentAmount());
            //System.Console.WriteLine("Hourly Employee Payment: " + hourlyEmployee.GetPaymentAmount());
            //System.Console.WriteLine("Commision Employee Payment: " + commisionEmployee.GetPaymentAmount());
            //System.Console.WriteLine("Base+Commision Employee Payment: " + basePlusCommisionEmployee.GetPaymentAmount());
            //System.Console.WriteLine("Invoice Payment: " + invoice.GetPaymentAmount());

            // Let's use polymorphism
            IPayable payable = null;
            payable = salariedEmploye;
            System.Console.WriteLine("Salaried Employee Payment: " + payable.GetPaymentAmount());
            payable = hourlyEmployee;
            System.Console.WriteLine("Hourly Employee Payment: " + payable.GetPaymentAmount());
            payable = commisionEmployee;
            System.Console.WriteLine("Commision Employee Payment: " + payable.GetPaymentAmount());
            payable = basePlusCommisionEmployee;
            System.Console.WriteLine("Basa+Commision Employee Payment: " + payable.GetPaymentAmount());
            payable = invoice;
            System.Console.WriteLine("Invoice Payment: " + payable.GetPaymentAmount());

            // using List
            //List<Employee> employeeList = new List<Employee>();
            //employeeList.Add(salariedEmploye);
            //employeeList.Add(invoice);


            List<IPayable> payableList = new List<IPayable>();
            payableList.Add(salariedEmploye);
            payableList.Add(hourlyEmployee);
            payableList.Add(commisionEmployee);
            payableList.Add(basePlusCommisionEmployee);
            payableList.Add(invoice);
            System.Console.WriteLine("********** Starting iterating through the list.");
            foreach (IPayable pay in payableList) {
                System.Console.WriteLine(pay);
                System.Console.WriteLine(pay.GetPaymentAmount());
                System.Console.WriteLine();
            
            }
            




            System.Console.ReadLine();


        }
    }
}
