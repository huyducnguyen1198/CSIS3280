﻿using System;

namespace CS3280InterfaceRunTimePoly
{
    class Program
    {
        static void Main(string[] args)
        {
            IComparable iComparable1;
            IComparable iComparable2;
            Car c1 = new Car("Toyota", "Corolla", "12345678", "Red");
            Car c2 = new Car("Toyota", "Camry", "23456789", "Beidge");

            Person p1 = new Person("Arpit", "Christi", "111-111-1111");
            Person p2 = new Person("John", "Doe", "111-111-1111");

            iComparable1 = c1;
            iComparable2 = c2;

            int comparisionResult = iComparable1.CompareTo(iComparable2);

            System.Console.WriteLine("***** Car Comparision  ******");
            System.Console.WriteLine("Result is: " + comparisionResult);

            iComparable1 = p1;
            iComparable2 = p2;

            comparisionResult = iComparable1.CompareTo(iComparable2);
            System.Console.WriteLine("***** Person Comparision  ******");
            System.Console.WriteLine("Result is: " + comparisionResult);
            System.Console.ReadLine();



        }
    }
}
