﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS3280Chapter12AbstractClass
{
    class Program
    {
        static void Main(string[] args)
        {
            //var salariedEmploye = new SalariedEmployee("John", "Smith", "111-111-1111", 800m);
            //var hourlyEmployee = new HourlyEmployee("Karen", "Price", "222-222-222", 16.5m, 40);
            //var commisionEmployee = new CommisionEmployee("Sue", "Jones", "333-333-333", 1000m, 0.06m);
            //var basePlusCommisionEmployee = new BasePlusCommisionEmployee("Bob", "Lewis", "444-444-4444", 1000m, 0.04m, 300);


            
            
            Console.ReadLine();
        }
    }
}
