﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS3280Chapter12AbstractClass
{
    class Program
    {
        static void Main(string[] args)
        {
            SalariedEmployee salariedEmploye = new SalariedEmployee("John", "Smith", "111-111-1111", 800m);
            HourlyEmployee hourlyEmployee = new HourlyEmployee("Karen", "Price", "222-222-222", 22.5m, 40);
            CommisionEmployee commisionEmployee = new CommisionEmployee("Sue", "Jones", "333-333-333", 1000m, 0.10m);
            BasePlusCommisionEmployee basePlusCommisionEmployee = new BasePlusCommisionEmployee("Bob", "Lewis", "444-444-4444", 1000m, 0.08m, 300);

            //I want to give one time, 10% raise to BasePlusCommisionEmployee on base salary only.

            //Employee employee = salariedEmploye;
            //System.Console.WriteLine(employee.Earning());
            //employee = hourlyEmployee;
            //System.Console.WriteLine(employee.Earning());


            //basePlusCommisionEmployee.BaseSalary = basePlusCommisionEmployee.BaseSalary * 1.1m;
            // Casting.
            //Employee employee = salariedEmploye;
            //BasePlusCommisionEmployee b = (BasePlusCommisionEmployee)employee;
            //b.BaseSalary = b.BaseSalary * 1.1m;

            //employee = commisionEmployee;
            //CommisionEmployee c = (CommisionEmployee)employee;
            //c.CommisionRate = c.CommisionRate * 1.1m;

            

            Employee[] employeeArray = new Employee[4];
            employeeArray[0] = salariedEmploye;
            employeeArray[1] = hourlyEmployee;
            employeeArray[2] = commisionEmployee;
            employeeArray[3] = basePlusCommisionEmployee;

            foreach (Employee emp in employeeArray) {
                System.Console.WriteLine(emp);
                // Question: why an exception here?
                //SalariedEmployee s = (SalariedEmployee)emp;
                //System.Console.WriteLine(s.Earning());
                if (emp is BasePlusCommisionEmployee) {
                    BasePlusCommisionEmployee b = (BasePlusCommisionEmployee)emp;
                    b.BaseSalary = b.BaseSalary * 1.1m;
                    // Question: why an exception here?
                    //SalariedEmployee s = (SalariedEmployee)emp;
                    //System.Console.WriteLine(s.Earning());
                }

                System.Console.WriteLine(emp.Earning());
                
            }



            Console.ReadLine();
        }
    }
}
