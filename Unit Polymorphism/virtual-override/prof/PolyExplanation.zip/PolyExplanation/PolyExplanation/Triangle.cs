﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolyExplanation
{
    class Triangle
    {
        public string Name { get; set; }

        public Triangle()
        {

        }

        public void Draw()
        {
            System.Console.WriteLine("Drawing a " + Name);
        }

        public void MoveToLocation(int x, int y)
        {
            System.Console.WriteLine("Moving the Triangle at location " + x + " " + y);
        }

        public void GrowSize(int percent)
        {
            System.Console.WriteLine("Growing the size of Triangle by " + percent + "%");

        }
    }
}
