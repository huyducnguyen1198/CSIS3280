﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolyExplanation
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Enter Choice: 1 for Circle, 2 for Rectangle and 3 for triangle");
            int choice = int.Parse(System.Console.ReadLine());
            if (choice == 1)
            {
                Circle c = new Circle();
                c.Draw();
                c.MoveToLocation(4, 5);
                c.GrowSize(20);
                c.MoveToLocation(4, 10);
            }
            else if (choice == 2)
            {
                Triangle t = new Triangle();
                t.Draw();
                t.MoveToLocation(4, 5);
                t.GrowSize(20);
                t.MoveToLocation(4, 10);

            }
            else if (choice == 3)
            {
                Rectangle r = new Rectangle();
                r.Draw();
                r.MoveToLocation(4, 5);
                r.GrowSize(20);
                r.MoveToLocation(4, 10);
            }

            System.Console.ReadLine();

        }
    }
}
