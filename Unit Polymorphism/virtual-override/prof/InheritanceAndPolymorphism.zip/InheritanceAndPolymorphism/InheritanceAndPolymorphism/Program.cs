﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceAndPolymorphism
{
    class Program
    {
        static void Main(string[] args)
        {
            CommisionEmployee commisionEmployee = new CommisionEmployee("Alex", "Doe", "111-111-1111", 5000m, 0.20m);
            BasePlusComissionEmployee basePlusComissionEmployee = new BasePlusComissionEmployee("Jane", "Lee", "222-222-2222", 4000m, 0.10m, 800m);
            BasePlusComissionEmployee basePlusCommisionEmployee2 = new BasePlusComissionEmployee("Joe", "Taylor", "333-333-3333", 3000m, 0.08m, 900m);

            /*
            //commisionEmployee.SSN = "333-333-3333"; Not allowed.
            System.Console.WriteLine("Commision Employee Info:");
            
            System.Console.WriteLine("Gross Sales:" + commisionEmployee.GrossSales);
            //System.Console.WriteLine("SSN:" + commisionEmployee.SSN);
            System.Console.WriteLine("Earning:" + commisionEmployee.Earning());


            // Base + Commision Employee Info
            System.Console.WriteLine("Base + Commision Employee Info:");
            System.Console.WriteLine("Gross Sales:" + basePlusComissionEmployee.GrossSales);
            //System.Console.WriteLine("SSN:" + basePlusComissionEmployee.SSN);
            System.Console.WriteLine("Earning:" + basePlusComissionEmployee.Earning());

            System.Console.WriteLine();
            System.Console.WriteLine();
            System.Console.WriteLine();
            System.Console.WriteLine();

            commisionEmployee.PrintInfo();
            System.Console.WriteLine();
            System.Console.WriteLine();
            System.Console.WriteLine();
            basePlusComissionEmployee.PrintInfo();


    */
            System.Console.WriteLine("***********************************Polymorphism Starts");
            // base clas reference points to the child class object 
            // commisionEmployee reference points to the  new BasePlusComissionEmployee("Jane", "Lee", "222-222-2222", 4000m, 0.10m, 800m);

            CommisionEmployee commisionEmployee1 = new BasePlusComissionEmployee("Jane", "Lee", "222-222-2222", 4000m, 0.10m, 800m);
            // we want to perform some operation.
            // operations via inheritance

            // expectation is this will print earing of base + commision employee. 
            // 400$ for commision employee (base class)
            // 1200$ for base + commision employhee (child class)

            System.Console.WriteLine(commisionEmployee1.Earning());


            System.Console.WriteLine("************base class reference = child class reference");
            commisionEmployee = basePlusComissionEmployee;
            System.Console.WriteLine(commisionEmployee.Earning());

            System.Console.WriteLine("************Building an array of employees");
            CommisionEmployee[] commisionEmployeesArray = new CommisionEmployee[3];
            commisionEmployeesArray[0] = commisionEmployee;
            commisionEmployeesArray[1] = basePlusComissionEmployee;
            commisionEmployeesArray[2] = basePlusCommisionEmployee2;

            for (int i = 0; i < commisionEmployeesArray.Length; i++) {
                System.Console.WriteLine("***" + commisionEmployeesArray[i].Earning());
            }

            System.Console.ReadLine();



            
            
        }
    }
}
