﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPModeling
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             We will have one instructor
             that instructor will offer 2 courses
             So, catalog will have two course. 
             we will  have two student.
             First student will register for both the courses in catalog.
             Second student will registesr for only one course in the catalog. 
             */


            Instructor instructor1 = new Instructor("Arpit", "Chrisit", "W123456", "CS");
            //instructor1.PrintInstructor();

            ClassCatalog classCatalog = new ClassCatalog();

            WeberClass weberClassFinance = new WeberClass("12345", "Finance 101", "FIN101", null, "Finacnce", 30);
            instructor1.OffersACourse(classCatalog, weberClassFinance);
            //weberClassFinance.PrintClassInfo();
            instructor1.OffersACourse(classCatalog, "98765", "Windows OOP", "CS3280", 24);

            //weberClassFinance and catalog._weberClasse[0]

            // students are created here. 

            Student student1 = new Student("W99999", "Aric", "Doe");
            Student student2 = new Student("W88888", "Jane", "Lee");

            // student 1 registers for both the classes

            student1.RegistersForAClass(classCatalog._weberClasses[0]);
            student1.RegistersForAClass(classCatalog._weberClasses[1]);
            
            // studnet 2 registers for finance class
            student2.RegistersForAClass(classCatalog._weberClasses[0]);

            // studnet 1 current enrollement is 2
            // student 2 current enrollment is 1
            // finance has 2 students. 
            // Windows OOP has only 1 student. 
            
            classCatalog.PrintCatalog();

            System.Console.WriteLine();
            System.Console.WriteLine();
            System.Console.WriteLine();

            student1.PrintStudnetInfo();
            student2.PrintStudnetInfo();

            System.Console.WriteLine();
            System.Console.WriteLine();
            System.Console.WriteLine();


            System.Console.WriteLine("The clases " + student1._firstName + " " + student1._lastName + " is enrolled in.");
            student1.PrintClassesInformationForStudent();


            System.Console.ReadLine();


           
        }
    }
}
