﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccessLayer
{
    public static class Utility
    {
        public static Organization.DepartmentsDataTable GetDepartments() {

            Organization.DepartmentsDataTable dtDeptTable = new Organization.DepartmentsDataTable();
            OrganizationTableAdapters.DepartmentsTableAdapter deptAdapater = new OrganizationTableAdapters.DepartmentsTableAdapter();
            deptAdapater.Fill(dtDeptTable);

            return dtDeptTable;
        }

        public static void SaveEmployee(string fname, string lname, string ssn, int deptID, decimal salary, decimal commisionRate, decimal Sales) {

            // EmployeeTable and the New Row techniqe to have new row inserted to the database. 

            Organization.EmployeesDataTable dtEmpTable = new Organization.EmployeesDataTable();
            OrganizationTableAdapters.EmployeesTableAdapter empAdapter = new OrganizationTableAdapters.EmployeesTableAdapter();
            empAdapter.Fill(dtEmpTable);

            Organization.EmployeesRow newEmpRow = dtEmpTable.NewEmployeesRow();
            newEmpRow.FName = fname;
            newEmpRow.Lname = lname;
            newEmpRow.SSN = ssn;
            newEmpRow.DeptID = deptID;
            newEmpRow.Salary = salary;
            newEmpRow.Sales = Sales;
            newEmpRow.Commision = commisionRate;

            dtEmpTable.AddEmployeesRow(newEmpRow);


            empAdapter.Update(dtEmpTable);
        }
    }
}
