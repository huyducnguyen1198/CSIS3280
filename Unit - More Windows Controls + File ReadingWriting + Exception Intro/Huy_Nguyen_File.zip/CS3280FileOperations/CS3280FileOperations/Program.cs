﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS3280FileOperations
{
    class Program
    {
        static void Main(string[] args)
        {

            // FILE STREAM DEMO
            System.IO.FileStream fileStream = new System.IO.FileStream("C:\\arpit\\personal\\teaching\\3280\\FileTest\\FileStream.txt", System.IO.FileMode.OpenOrCreate);
            List<byte> byteList = new List<byte>();
            int b;
            while ((b = fileStream.ReadByte()) != -1) {
                byteList.Add((byte)b);
            }

            fileStream.Close();

            fileStream = new System.IO.FileStream("C:\\arpit\\personal\\teaching\\3280\\FileTest\\FileStream1.txt", System.IO.FileMode.OpenOrCreate);
            
            fileStream.Write(byteList.ToArray(), 0, byteList.Count - 1);
            fileStream.Close();


            // StreamReader and StreamWriter demo. 
            List<int> streamList = new List<int>();
            System.IO.StreamReader streamReader = new System.IO.StreamReader("C:\\arpit\\personal\\teaching\\3280\\FileTest\\StreamReaderWriter.txt");
            int stream;
            while ((stream = streamReader.Read()) != -1) {
                streamList.Add(stream);
            }

            streamReader.Close();

            System.IO.StreamWriter streamWriter = new System.IO.StreamWriter("C:\\arpit\\personal\\teaching\\3280\\FileTest\\StreamReaderWriter1.txt");
            streamWriter.Write(streamList.Select(x => (char)x).ToArray());
            //streamList.ForEach(x => streamWriter.Write((char)x));
            streamWriter.Close();

            // Text Reader and Text Writer class.

            System.IO.TextReader textReader = new System.IO.StreamReader("C:\\arpit\\personal\\teaching\\3280\\FileTest\\TextReaderWriter.txt");
            List<String> lines = new List<string>();
            string nextline;
            while ((nextline = textReader.ReadLine()) != null) {
                lines.Add(nextline);
            }
            
            textReader.Close();
            System.Diagnostics.Debug.WriteLine(lines);

            System.IO.TextWriter textWriter = new System.IO.StreamWriter("C:\\arpit\\personal\\teaching\\3280\\FileTest\\TextReaderWriter1.txt");
            lines.ForEach(x => textWriter.WriteLine(x));

            textWriter.Close();
        }
    }
}
