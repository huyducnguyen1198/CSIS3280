﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Security;

namespace CS3280FileOperations
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream fileStreamRead = null;
            FileStream fileStreamWrite = null;
            try
            {

                fileStreamRead = new System.IO.FileStream("C:/arpit/personal/teaching/3280/FileTest/FileStream.txt", System.IO.FileMode.Open);

                List<byte> byteList = new List<byte>();
                int b;
                while ((b = fileStreamRead.ReadByte()) != -1)
                {
                    byteList.Add((byte)b);
                }


                System.Diagnostics.Debug.WriteLine(byteList);

                fileStreamRead.Close();

                fileStreamWrite = new System.IO.FileStream("C:/arpit/personal/teaching/3280/FileTest/FileStream1.txt", System.IO.FileMode.OpenOrCreate);

                fileStreamWrite.Write(byteList.ToArray(), 0, byteList.Count);


            }
            catch (FileNotFoundException fex)
            {
                System.Console.WriteLine(fex);
                System.Console.WriteLine(fex.Message);
                System.Console.WriteLine(fex.FileName);

            }
            catch (SecurityException securityException)
            {
                System.Console.WriteLine(securityException);
                System.Console.WriteLine(securityException.Message);
                System.Console.WriteLine(securityException.PermissionState);
                System.Console.WriteLine(securityException.PermissionType);
            }
            catch (ArgumentNullException nex)
            {
                System.Console.WriteLine(nex);
                System.Console.WriteLine(nex.Message);
                System.Console.WriteLine(nex.ParamName);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex);
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
            finally
            {
                if (fileStreamRead != null)
                    fileStreamRead.Close();
                if (fileStreamWrite != null)
                    fileStreamWrite.Close();
            }
            

            //TODO: Build Exception handling mechanism for the program below. 

            // StreamReader and StreamWriter
            StreamReader reader = new StreamReader("M:\\arpit\\temp\\StreamReader.txt");

            int ch;
            List<int> streamList = new List<int>();
            while ((ch = reader.Read()) != -1) {
                streamList.Add(ch);
            }

            reader.Close();

            StreamWriter writer = new StreamWriter("M:\\arpit\\temp\\StreamWriter.txt");
            streamList.ForEach(x => writer.Write((char)x));
            writer.Close();

            // TextReader and TextWriter

            TextReader textReader = new StreamReader("M:\\arpit\\temp\\StreamReader.txt");
            string line;
            List<string> textList = new List<string>();
            while ((line = textReader.ReadLine()) != null) {
                textList.Add(line);
            }
            
            System.Diagnostics.Debug.WriteLine(textList);


            System.Console.ReadLine();
        }
    }
}
